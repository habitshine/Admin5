<template>
    <div class="com-select">
        <div class="pos-r">
            <h5>{{opts.title}}</h5>
            <!-- 搜索 -->
            <div class="input-group">
                <input v-model="keyword" type="text" class="form-control" :placeholder="opts.placeholder" @blur="blur" @focus="focus" @keyup.delete="back">
                <span class="input-group-btn">
                    <a @click="empty" class="btn btn-default">
                        <i class="glyphicon glyphicon-refresh">
                    </a>
                    <button @click="togglePopup" class="btn btn-default" type="button">
                        <span class="caret" :class="{rotate: popup.show}"></span>
                </button>
                </span>
            </div>
            <!-- popup -->
            <v-drop-down :opts="{show: popup.show}">
                <!-- 内容 -->
                <ul class="content">
                    <li :class="{active: value == option.value}" @click="selectOption(option)" v-for="(option, i) in options">{{option.label}}</li>
                </ul>
            </v-drop-down>
        </div>
    </div>
</template>
<script>
import VDropDown from './DropDown'

export default {
    name: 'Select',

    props: {
        opts: {
            type: Object
        },
        value: {}
    },

    components: {
        VDropDown
    },

    data() {
        return {
            keyword: '',
            popup: {
                show: false
            }
        }
    },

    methods: {
        focus(e) {
            e.target.select();
            this.popup.show = true;
        },
        /**
         * 离开搜索框
         * 校验是否选中值, 未选则中清空keyword
         * 关闭弹出菜单
         */
        blur() {
            this.popup.show = false;
            if (null == this.value) {
                this.keyword = ''
            }
        },
        /**
         * 弹出对话框
         */
        togglePopup() {
            this.popup.show = !this.popup.show;
        },

        /**
         * 单选事件, 传递input事件, 模拟v-model
         */
        selectOption(option) {
            this.$emit('input', option.value);
            this.keyword = option.label;
            this.popup.show = false;
        },

        empty() {
            this.popup.show = false;
            this.keyword = '';
            this.$emit('input', null);

        },

        back() {
            this.$emit('input', null);
        },

        close() {
            this.popup.show = false;
        },

        leavePopup() {
            this.popup.show = false;
        }
    },

    computed: {
        options() {
            if ('' == this.keyword || null != this.value) {
                return this.opts.children;
            } else {
                return this.opts.children.filter(options => {
                    return (-1 != options.label.indexOf(this.keyword));
                });
            }
        }
    }
}
</script>
<style scoped lang=scss>
$color: #69c;
$padding:15px;
$disable_color: #ccc;
.rotate {
    -webkit-transform: rotate(180deg);
    transform: rotate(180deg);
}

.caret {
    transition: all .5s;
}

.com-select {
    /*padding: 0;*/
    button {
        outline: none;
    }
    .pos-r {
        position: relative;
        width: 100%;

        ul.content {
            box-sizing: border-box;
            position: relative;
            overflow-y: auto;
            overflow-x: hidden;
            width: 100%;
            max-height: 320px;
            margin-top: 15px;
            li {
                /*width: 100%;*/
                /*display: inline-block;*/
                font-size: 12px;
                list-style: none;
                padding: $padding;
                cursor: pointer;
                &:hover {
                    background: #f7f7f7;
                    border-radius: 4px;
                }
            }
            li.active {
                color: $color;
            }
            li.disable {
                color: $disable_color;
            }
            li:hover {
                opacity: 0.6;
            }
        }
    }
}
</style>
